import{e as s,r as a}from"./vendor-core-B916t8Fz.js";function o(){const r=s();return a.useMemo(()=>r,[r])}export{o as u};
