import{j as e}from"./index-C59BPRiu.js";import{r as i}from"./vendor-core-B916t8Fz.js";import{M as x}from"./index-DASetJK0.js";import{c as I,h as o,l as n,B as m,a0 as j,G as h,I as k,S as p,a8 as C,m as M,o as T}from"./vendor-ui-B9tod6JH.js";import"./vendor-utils-D7d70aJA.js";import"./index-3P2037Tg.js";import"./react-markdown-BkYuC1zX.js";import"./vendor-charts-kClOsdvq.js";import"./highlight-oe0N3Op3.js";const{TextArea:u}=k,{Text:c}=I,L=({userPrompt:s,systemPrompt:a,onUserPromptChange:v,onSystemPromptChange:b,disabled:d=!1})=>{const[f,g]=i.useState("user"),[t,y]=i.useState(!1),[r,N]=i.useState(!1),w=[{key:"user",label:e.jsxs(p,{children:[e.jsx(C,{}),e.jsx("span",{children:"用户提示词"}),s&&e.jsx("span",{className:"w-2 h-2 bg-blue-500 rounded-full"})]}),children:e.jsxs("div",{className:"space-y-3",children:[e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("div",{className:"flex items-center space-x-2",children:[e.jsx(c,{type:"secondary",className:"text-sm",children:"输入需要优化的提示词内容，支持 Markdown 格式"}),e.jsx(o,{title:"支持Markdown语法，如**粗体**、*斜体*、`代码`等",children:e.jsx(n,{className:"text-gray-400"})})]}),e.jsx(m,{type:"text",size:"small",icon:t?e.jsx(j,{}):e.jsx(h,{}),onClick:()=>y(!t),disabled:!s.trim(),children:t?"编辑":"预览"})]}),t?e.jsx("div",{className:"border border-gray-200 rounded-lg p-4 bg-gray-50 min-h-[200px]",children:s.trim()?e.jsx(x,{children:s}):e.jsx("div",{className:"text-gray-400 text-center py-8",children:"暂无内容可预览"})}):e.jsx(u,{value:s,onChange:l=>v(l.target.value),placeholder:`请输入您的提示词内容，支持 Markdown 格式...

示例：
## 任务描述
请你扮演一个**专业的文案写手**，帮我：
1. 分析目标受众
2. 制定内容策略
3. 撰写吸引人的文案

\`\`\`
要求：语言简洁有力，突出产品优势
\`\`\``,rows:10,disabled:d,showCount:!0,maxLength:5e3,className:"resize-none font-mono text-sm"})]})},{key:"system",label:e.jsxs(p,{children:[e.jsx(M,{}),e.jsx("span",{children:"系统提示词"}),a&&e.jsx("span",{className:"w-2 h-2 bg-orange-500 rounded-full"})]}),children:e.jsxs("div",{className:"space-y-3",children:[e.jsxs("div",{className:"flex items-center justify-between",children:[e.jsxs("div",{className:"flex items-center space-x-2",children:[e.jsx(c,{type:"secondary",className:"text-sm",children:"可选：定义AI的角色和行为规范，支持 Markdown 格式"}),e.jsx(o,{title:"系统提示词用于设定AI的基本行为模式和角色定位",children:e.jsx(n,{className:"text-gray-400"})})]}),e.jsx(m,{type:"text",size:"small",icon:r?e.jsx(j,{}):e.jsx(h,{}),onClick:()=>N(!r),disabled:!a.trim(),children:r?"编辑":"预览"})]}),r?e.jsx("div",{className:"border border-gray-200 rounded-lg p-4 bg-gray-50 min-h-[200px]",children:a.trim()?e.jsx(x,{children:a}):e.jsx("div",{className:"text-gray-400 text-center py-8",children:"暂无内容可预览"})}):e.jsx(u,{value:a,onChange:l=>b(l.target.value),placeholder:`可选：输入系统提示词来定义AI的角色和行为规范...

示例：
# 角色设定
你是一位**资深的AI提示词工程师**，具有以下特质：

## 专业能力
- 深度理解自然语言处理原理
- 熟练掌握提示词优化技巧
- 具备丰富的实战经验

## 工作原则
1. **准确性优先**：确保输出内容准确无误
2. **简洁明了**：表达清晰，避免冗余
3. **用户导向**：始终以用户需求为中心`,rows:10,disabled:d,showCount:!0,maxLength:2e3,className:"resize-none font-mono text-sm"})]})}];return e.jsxs("div",{className:"w-full",children:[e.jsx(T,{activeKey:f,onChange:g,items:w,size:"small",tabBarGutter:16,className:"prompt-editor-tabs"}),e.jsx("div",{className:"mt-4 p-3 bg-blue-50 border border-blue-200 rounded-lg",children:e.jsxs("div",{className:"flex items-start space-x-2",children:[e.jsx(n,{className:"text-blue-500 mt-0.5"}),e.jsxs("div",{children:[e.jsx(c,{className:"text-sm text-blue-700 font-medium",children:"Markdown 支持提示"}),e.jsxs("div",{className:"text-xs text-blue-600 mt-1 space-y-1",children:[e.jsx("div",{children:"• **粗体文本** 或 __粗体文本__"}),e.jsx("div",{children:"• *斜体文本* 或 _斜体文本_"}),e.jsx("div",{children:"• `行内代码` 或 ```代码块```"}),e.jsx("div",{children:"• # 标题 ## 二级标题 ### 三级标题"}),e.jsx("div",{children:"• - 列表项 或 1. 有序列表"})]})]})]})})]})};export{L as default};
