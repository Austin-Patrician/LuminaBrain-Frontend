import{j as r,t as e}from"./index-C59BPRiu.js";import{r as o}from"./vendor-core-B916t8Fz.js";import{M as a}from"./index-DASetJK0.js";import{c as s,C as i}from"./vendor-ui-B9tod6JH.js";import"./vendor-utils-D7d70aJA.js";import"./index-3P2037Tg.js";import"./react-markdown-BkYuC1zX.js";import"./vendor-charts-kClOsdvq.js";import"./highlight-oe0N3Op3.js";const m=`
# h1

<br/>

## h2

<br/>

**Paragraph** Lorem ipsum is placeholder text commonly used in the graphic, print, and publishing industries for previewing layouts and visual mockups.

<br/>

[Link (https://www.google.com/)](https://www.google.com/)

<br/>

###### Lists

<br/>

- [x] Write the press release
- [ ] Update the website
- [ ] Contact the media

<br/>

---

<br/>

###### A table:

<br/>

| Syntax      | Description | Test Text     |
| :---        |    :----:   |          ---: |
| Header      | Title       | Here's this   |
| Paragraph   | Text        | And more      |

<br/>

\`\`\`tsx
import React from 'react';
import ReactDOM from 'react-dom';
import ReactMarkdown from 'react-markdown';
import rehypeHighlight from 'rehype-highlight';

ReactDOM.render(
  <ReactMarkdown rehypePlugins={[rehypeHighlight]}>{'# Your markdown here'}</ReactMarkdown>,
  document.querySelector('#content')
);
\`\`\`

<br/>

> A block quote with ~~strikethrough~~ and a URL: [https://reactjs.org](https://reactjs.org).

`;function b(){const[t]=o.useState(m);return r.jsxs(r.Fragment,{children:[r.jsx(s.Link,{href:"https://github.com/remarkjs/react-markdown",style:{color:e.colors.palette.primary.default},className:"mb-4 block",children:"https://github.com/remarkjs/react-markdown"}),r.jsx(i,{title:"Mardown content",children:r.jsx(a,{children:t})})]})}export{b as default};
